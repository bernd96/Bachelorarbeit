^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package fub_controller
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.2.0 (2017-02-22)
------------------
* fix CMake warnings on Ubuntu 16.04/ROS Kinetic (T2645)
* refactor topic names and -spaces (T3102)

1.1.1 (2016.02.01)
------------------
* Publish wanted speed and front wheel angle (T2655)

1.1.0 (2016-11-17)
------------------
* use TCP_NODELAY transport hint for incoming data (T2493)

1.0.0 (2016-11-02)
------------------
* Initial release
